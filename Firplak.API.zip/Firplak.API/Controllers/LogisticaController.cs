﻿using Firplak.Domain.Interfaces;
using Firplak.Domain.DTOs;
using Firplak.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace Firplak.API.Controllers
{

    
    [ApiController]
    public class LogisticaController: ControllerBase
    {
        private readonly IEntregasServices _entregasServices;

        public LogisticaController(IEntregasServices entregasServices)
        {
            _entregasServices = entregasServices;
        }

        //[HttpGet("api/entregas")]
        //public async Task<ActionResult<List<Entrega>>> GetEntregas()
        //{
        //    var entregas = await _entregasServices.GetEntregas(entrega => true);
        //    return Ok(entregas);
        //}

        [HttpGet("api/entregas")]
        public ActionResult<List<EntregaDto>> GetEntregas()
        {
            var entregas = _entregasServices.GetEntregas(e => true);
            if (entregas == null || !entregas.Any())
            {
                return NotFound();
            }
            return Ok(entregas);
        }




    }
}
