﻿using Firplak.Domain.Models;
using Firplak.Domain.DTOs;
using System.Linq.Expressions;

namespace Firplak.Domain.Interfaces
{
    public interface IEntregasServices
    {
        //Task<List<Entrega>> GetEntregas(Expression<Func<Entrega, bool>> condition);
        
        List<EntregaDto> GetEntregas(Expression<Func<Entrega, bool>> condition);
    }
}