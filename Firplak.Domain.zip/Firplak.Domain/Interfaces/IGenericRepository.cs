﻿using Firplak.Domain.Models;

namespace Firplak.Infrastructure.Repositories
{
    public interface IGenericRepository<T> where T : Base
    {
        Task<bool> Delete(T entity);
        bool Execute(string SQL);
        Task<T> Get(System.Linq.Expressions.Expression<Func<T, bool>> condition);
        Task<bool> Insert(T entity);
        IQueryable<T> List(System.Linq.Expressions.Expression<Func<T, bool>>? Condicion);
        Task<IEnumerable<T>> ListAsync(System.Linq.Expressions.Expression<Func<T, bool>>? Condicion);
        Task<bool> Update(T entity);
    }
}