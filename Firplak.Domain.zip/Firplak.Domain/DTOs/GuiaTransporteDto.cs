﻿using Firplak.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firplak.Domain.DTOs
{
    public class GuiaTransporteDto
    {


        public Guid GuiaTransporteID { get; set; }
        public string TipoTransporte { get; set; }
        public string NumeroGuia { get; set; }
        


    }
}
