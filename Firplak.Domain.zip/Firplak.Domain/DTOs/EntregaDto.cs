﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firplak.Domain.DTOs
{
    public class EntregaDto
    {

        public Guid EntregaID { get; set; }
        public DateTime? FechaDespacho { get; set; }
        public Guid? GuiaTransporteID { get; set; }
        public DateTime? FechaEntregaReal { get; set; }

        public GuiaTransporteDto GuiaTransporte { get; set; }

        //public ICollection<FacturaDto> Factura { get; set; }
    }
}
