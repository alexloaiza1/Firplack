﻿using Firplak.Domain.Models;
using Firplak.Domain.Interfaces;
using Firplak.Domain.DTOs;
using AutoMapper;
using Firplak.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Firplak.Domain.Services
{
    public class EntregasServices : IEntregasServices
    {
        private readonly IGenericRepository<Entrega> _repositoryEntrega;
        private readonly IMapper _mapper;



        public EntregasServices(IGenericRepository<Entrega> repositoryEntrega, IMapper mapper)
        {
            _repositoryEntrega = repositoryEntrega;
            _mapper = mapper;
        }

        //public async Task<List<Entrega>> GetEntregas(Expression<Func<Entrega, bool>> condition)
        //{
        //    IEnumerable<Entrega> entregas = await _repositoryEntrega.ListAsync(condition).ConfigureAwait(false);

        //    if (entregas is null)
        //        return new List<Entrega>();

        //    return entregas.ToList();
        //}


        public List<EntregaDto> GetEntregas(Expression<Func<Entrega, bool>> condition)
        {
            IQueryable<Entrega> entregasQuery = _repositoryEntrega.List(condition);

            if (entregasQuery == null)
                return new List<EntregaDto>();

            List<EntregaDto> entregas = entregasQuery
                .Select(entrega => _mapper.Map<EntregaDto>(entrega))
                .ToList();

            return entregas;
        }



    }
}
